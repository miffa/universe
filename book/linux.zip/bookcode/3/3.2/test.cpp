#include "f.h"

int main()
{
	f();

	return 0;
}
