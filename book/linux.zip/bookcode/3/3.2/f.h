#ifndef F_H
#define F_H

int i = 0;

void f();

#endif