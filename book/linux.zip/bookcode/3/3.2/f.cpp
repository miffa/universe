#include <stdio.h>
#include "f.h"

void f()
{
	printf("in f: %d\n", i);
}