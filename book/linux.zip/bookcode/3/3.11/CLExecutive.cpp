#include "CLExecutive.h"

CLExecutive::CLExecutive(CLCoordinator *pCoordinator)
{
	m_pCoordinator = pCoordinator;
}

CLExecutive::~CLExecutive()
{
}
