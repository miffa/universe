#ifndef CLMsgLoopManagerForSTLqueue_H
#define CLMsgLoopManagerForSTLqueue_H

#include "CLMessageLoopManager.h"

class CLMessageQueueBySTLqueue;

class CLMsgLoopManagerForSTLqueue : public CLMessageLoopManager
{
public:
	/*
	pMsgQueueӦ�Ӷ��з��䣬�Ҳ�����ʾ����delete
	*/
	CLMsgLoopManagerForSTLqueue(CLMessageQueueBySTLqueue *pMsgQueue);
	virtual ~CLMsgLoopManagerForSTLqueue();

protected:
	virtual CLStatus Initialize();
	virtual CLStatus Uninitialize();
	
	virtual CLMessage* WaitForMessage();

private:
	CLMsgLoopManagerForSTLqueue(const CLMsgLoopManagerForSTLqueue&);
	CLMsgLoopManagerForSTLqueue& operator=(const CLMsgLoopManagerForSTLqueue&);

private:
	CLMessageQueueBySTLqueue *m_pMsgQueue;
};

#endif